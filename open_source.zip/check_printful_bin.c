#include <stdio.h>
#include <stdlib.h>

// 判断字节是否为可打印字符
int is_printable(unsigned char byte) {
    return byte >= 0x20 && byte <= 0x7E;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_bin_file>\n", argv[0]);
        return 1;
    }

    const char *input_file = argv[1];

    FILE *in = fopen(input_file, "rb");
    if (!in) {
        perror("Error opening input file");
        return 1;
    }

    unsigned char byte;
    int all_printable = 1;  // 假设所有字节都是可打印字符
    int unprint_count = 0;
    long file_length = 0;   // 用于记录文件长度

    while (fread(&byte, 1, 1, in) == 1) {
        file_length++;  // 增加文件长度计数
        if (!is_printable(byte)) {
            all_printable = 0;  // 发现非可打印字符
            unprint_count++;
            // break;
        }
    }

    fclose(in);

    // 输出文件长度
    printf("File length: %ld bytes\n", file_length);

    if (all_printable) {
        printf("All bytes in the file are printable characters.\n");
        return 0;
    } else {
        printf("The file contains %d non-printable characters.\n",unprint_count);
        return 1;
    }
}