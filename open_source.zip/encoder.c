// 将shellcode进行编码并输出位shellcode.bin， 并且以0x7e为结尾
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <direct.h>  // For Windows
#else
#include <libgen.h>  // For POSIX systems
#endif
size_t encode_0(uint8_t *data_in, size_t len_in, uint8_t *data_out) {
    uint16_t val = 0;
    size_t bits = 0;
    size_t j = 0;
    for (size_t i = 0; i < len_in; i++) {
        val = (val << 8) | data_in[i];
        bits += 8;
        while (bits >= 7) {
            uint16_t tmp = val >> (bits - 7);
            size_t right_bits = 7;
            if ((tmp >= 0x40) & (tmp < 0x5e)) {
            } else {
                tmp = val >> (bits - 6);
                right_bits = 6;
            }
            data_out[j++] = tmp + 0x20;
            bits -= right_bits;
            val = val & ((1 << bits) - 1);
        }
    }
    if (bits != 0) {
        val = val << (6 - bits);
        data_out[j++] = val + 0x20;
    }
    data_out[j++] = 0x7e;
    return j; // 返回输出数据的长度
}
size_t encode(uint8_t *data_in, size_t len_in, uint8_t *data_out) {
    uint16_t val = 0;
    size_t bits = 0;
    size_t j = 0;
    for(size_t i = 0; i < len_in; i++)
    {
        val = (val<<8) | data_in[i];
        bits += 8;
        while (bits >= 7)
        {
            uint16_t tmp = val>>(bits-7); 
            size_t right_bits = 7;
            if((tmp >= 0x46))
            {
                //tmp [0x46, 0x7f)
                data_out[j++] = tmp -0x44 + 0x43; //[0x45, 0x7e)
            }
            else{
                tmp = val>>(bits-6); //tmp [0, 0x22] 
                data_out[j++] = tmp + 0x21; // [0x21, 0x43]
                right_bits = 6;
            }
            bits -= right_bits;
            val = val&((1<<bits)-1);
        }
    }
    if(bits != 0)
    {
        val = val<<(6-bits);
        if(val <= 0x22)
        {
            data_out[j++] = val + 0x21;
        }
        else
        {
            data_out[j++] = val*2 - 0x44 + 0x43;
        }
    }
    data_out[j++] = 0x44;
    return j;
}
char* remove_extension(const char* filename) {
    const char* last_dot = strrchr(filename, '.');
    const char* last_slash = NULL;

#ifdef _WIN32
    // last_slash = strrchr(filename, '\\');  // Windows path separator
    last_slash = strrchr(filename, '/');  // Windows path separator
#else
    last_slash = strrchr(filename, '/');  // POSIX path separator
#endif

    const char* file_start = (last_slash) ? (last_slash + 1) : filename;

    if (last_dot && (last_dot > last_slash)) {
        size_t len = last_dot - file_start;
        char* result = malloc(len + 1);
        if (result) {
            memcpy(result, file_start, len);
            result[len] = '\0';
        }
        return result;
    }
    return strdup(file_start); // 如果没有扩展名，返回文件名部分的副本
}
// 函数：拼接新的输出文件名
char* create_output_filename(const char* input_file) {
    char* file_without_extension = remove_extension(input_file);
    if (!file_without_extension) {
        return NULL;
    }

    size_t new_len = strlen(file_without_extension) + strlen("./temp/_encoded.bin") + 1;
    char* output_filename = malloc(new_len);
    if (!output_filename) {
        free(file_without_extension);
        return NULL;
    }

    snprintf(output_filename, new_len, "./temp/%s_encoded.bin", file_without_extension);
    free(file_without_extension);
    return output_filename;
}
int main(int argc, char *argv[]) {
    // 打开输入文件
    // FILE *fin = fopen("w32-exec-calc-shellcode.bin", "rb");
    FILE *fin = fopen(argv[1], "rb");
    if (!fin) {
        perror("Failed to open input file");
        return 1;
    }

    // 获取文件大小
    fseek(fin, 0, SEEK_END);
    size_t len_in = ftell(fin);
    fseek(fin, 0, SEEK_SET);

    // 分配内存读取文件内容
    uint8_t *data_in = malloc(len_in);
    if (!data_in) {
        perror("Failed to allocate memory");
        fclose(fin);
        return 1;
    }

    // 读取文件内容
    size_t read_len = fread(data_in, 1, len_in, fin);
    if (read_len != len_in) {
        perror("Failed to read file content");
        free(data_in);
        fclose(fin);
        return 1;
    }
    fclose(fin);

    // 分配内存用于输出数据
    uint8_t *data_out = malloc(len_in * 2); // 假设输出数据不会超过输入数据的两倍
    if (!data_out) {
        perror("Failed to allocate memory for output");
        free(data_in);
        return 1;
    }

    // 调用 encode 函数
    size_t len_out = encode(data_in, len_in, data_out);

    // 保存输出数据到文件
    // FILE *fout = fopen("shellcode.bin", "wb");
    // 创建输出文件名
    char* output_file = create_output_filename(argv[1]);
    printf("output_file: %s\n", output_file);

    // 打开输出文件
    FILE *fout = fopen(output_file, "wb");
    if (!fout) {
        perror("Failed to open file for writing");
        free(data_in);
        free(data_out);
        return 1;
    }

    size_t write_len = fwrite(data_out, 1, len_out, fout);
    if (write_len != len_out) {
        perror("Failed to write output data");
        free(data_in);
        free(data_out);
        fclose(fout);
        return 1;
    }
    fclose(fout);

    // 释放内存
    free(data_in);
    free(data_out);

    printf("Encoding completed successfully.\n");
    return 0;
}